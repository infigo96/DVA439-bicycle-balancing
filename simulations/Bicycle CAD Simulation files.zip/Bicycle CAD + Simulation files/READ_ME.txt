Bicycle CAD-Files - Contain all parts and a full model of a detailed bicycle model of the real bicycle.
Simulation Files - Contain all necessary files about the control loop simulations both MATLAB and ADAMS files. 
		   Only folders that include the work "Discrete" is a discrete controller the rest is Continuous
eigenvalues_L - Is a test file for checking the eigenvalues of the system.